#define _LARGEFILE64_SOURCE
#define _XOPEN_SOURCE 500
#include "xrg_int.h"
#include <errno.h>
#include <stdio.h>
#include <unistd.h>

/* Returns the item size for ptyp.
 * For bytea, return -1.
 * For fixed length items, returns their item size.
 * Return 0 on error.
 */
int xrg_itemsz_from_ptyp(int ptyp, char *errbuf, int errbuflen) {
  switch (ptyp) {
  case XRG_PTYP_INT8:
    return 1;
  case XRG_PTYP_INT16:
    return 2;
  case XRG_PTYP_INT32:
    return 4;
  case XRG_PTYP_INT64:
    return 8;
  case XRG_PTYP_INT128:
    return 16;
  case XRG_PTYP_FP32:
    return 4;
  case XRG_PTYP_FP64:
    return 8;
  case XRG_PTYP_BYTEA:
    return -1;
  default:
    break;
  }

  snprintf(errbuf, errbuflen, "xrg_itemsz: unsupported ptyp %s",
           xrg_ptyp_to_string(ptyp));
  return 0;
}

/* Returns the item size for ptyp & ltyp.
 * For bytea, return -1.
 * For fixed length items, returns their item size.
 * Return 0 on error.
 */
int xrg_itemsz(int ptyp, int ltyp, int precision, char *errbuf, int errbuflen) {
  switch (ltyp) {
  case XRG_LTYP_NONE:
    switch (ptyp) {
    case XRG_PTYP_INT8:
      return 1;
    case XRG_PTYP_INT16:
      return 2;
    case XRG_PTYP_INT32:
      return 4;
    case XRG_PTYP_INT64:
      return 8;
    case XRG_PTYP_INT128:
      return 16;
    case XRG_PTYP_FP32:
      return 4;
    case XRG_PTYP_FP64:
      return 8;
    }
    break;
  case XRG_LTYP_STRING:
  case XRG_LTYP_ARRAY:
    if (ptyp == XRG_PTYP_BYTEA) {
      return -1;
    }
    break;
  case XRG_LTYP_DECIMAL:
    if (ptyp == XRG_PTYP_INT64 && 1 <= precision && precision <= 18) {
      return 8;
    }
    if (ptyp == XRG_PTYP_INT128 && precision > 18) {
      return 16;
    }
    break;
  case XRG_LTYP_INTERVAL:
    if (ptyp == XRG_PTYP_INT128) {
      return 16;
    }
    break;
  case XRG_LTYP_TIME:
    if (ptyp == XRG_PTYP_INT64)
      return 8;
    break;
  case XRG_LTYP_DATE:
    if (ptyp == XRG_PTYP_INT32)
      return 4;
    break;
  case XRG_LTYP_TIMESTAMP:
    if (ptyp == XRG_PTYP_INT64)
      return 8;
    break;
  }

  if (ltyp == XRG_LTYP_DECIMAL) {
    snprintf(errbuf, errbuflen,
             "unsupported %s %s combination for precision %d",
             xrg_ptyp_to_string(ptyp), xrg_ltyp_to_string(ltyp), precision);
    return 0;
  }
  snprintf(errbuf, errbuflen, "xrg_itemsz: unsupported %s %s combination",
           xrg_ptyp_to_string(ptyp), xrg_ltyp_to_string(ltyp));
  return 0;
}

void xrg_bytea_print(const char *p) {
  int len = xrg_bytea_len(p);
  const char *ptr = xrg_bytea_ptr(p);
  fwrite(ptr, 1, len, stdout);
}

int64_t xrg_filesize(int fd, char *errbuf, int errbuflen) {
  int64_t pos = lseek64(fd, 0, SEEK_CUR);
  if (-1 == pos) {
    snprintf(errbuf, errbuflen, "xrg_filesize: %s", strerror(errno));
    return -1;
  }
  int64_t filesz = lseek64(fd, 0, SEEK_END);
  if (-1 == filesz) {
    snprintf(errbuf, errbuflen, "xrg_filesize: %s", strerror(errno));
    return -1;
  }
  lseek64(fd, pos, SEEK_SET);
  return filesz;
}

int xrg_readfully_at(int fd, int64_t offset, void *buf, int bufsz, char *errbuf,
                     int errbuflen) {
  char *p = buf;
  char *const q = buf + bufsz;

  while (p < q) {
    int n = pread(fd, p, q - p, offset);
    if (n > 0) {
      p += n;
      offset += n;
      continue;
    }
    if (n == 0) {
      snprintf(errbuf, errbuflen, "%s", "unexpected end of stream");
      return -1;
    }
    int eno = errno;
    if (eno == EINTR) {
      continue; /* retry */
    }
    // a real error
    snprintf(errbuf, errbuflen, "%s", strerror(errno));
    return -1;
  }

  return 0;
}

int xrg_readfully(int fd, void *buf, int bufsz, char *errbuf, int errbuflen) {
  char *p = buf;
  char *const q = buf + bufsz;

  while (p < q) {
    int n = read(fd, p, q - p);
    if (n > 0) {
      p += n;
      continue;
    }
    if (n == 0) {
      snprintf(errbuf, errbuflen, "%s", "unexpected end of stream");
      return -1;
    }
    int eno = errno;
    if (eno == EINTR) {
      continue; /* retry */
    }
    // a real error
    snprintf(errbuf, errbuflen, "%s", strerror(errno));
    return -1;
  }

  return 0;
}

int xrg_writefully(int fd, const void *buf, int bufsz, char *errbuf,
                   int errbuflen) {
  const char *p = buf;
  const char *const q = buf + bufsz;

  while (p < q) {
    int n = write(fd, p, q - p);
    if (n > 0) {
      p += n;
      continue;
    }
    if (n == 0) {
      snprintf(errbuf, errbuflen, "%s", "unexpected end of stream");
      return -1;
    }
    int eno = errno;
    if (eno == EINTR) {
      continue; /* retry */
    }
    // a real error
    snprintf(errbuf, errbuflen, "%s", strerror(errno));
    return -1;
  }

  return 0;
}
