#define _XOPEN_SOURCE 500
#include "xrg_int.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define process_fixed_int(T, MIN, MAX, bloom)                                  \
  {                                                                            \
    T minval = MAX;                                                            \
    T maxval = MIN;                                                            \
    const T *value = (const T *)data;                                          \
    for (int i = 0; i < nitem; i++) {                                          \
      if (flag[i])                                                             \
        continue;                                                              \
      T v = value[i];                                                          \
      minval = (v < minval) ? v : minval;                                      \
      maxval = (v > maxval) ? v : maxval;                                      \
      xrg_bloom_add(bloom, &v, sizeof(T));                                     \
    }                                                                          \
    *(T *)&rec->minval = minval;                                               \
    *(T *)&rec->maxval = maxval;                                               \
  }

#define process_fixed_fp(T, MIN, MAX, bloom)                                   \
  {                                                                            \
    T minval = MAX;                                                            \
    T maxval = MIN;                                                            \
    const T *value = (const T *)data;                                          \
    for (int i = 0; i < nitem; i++) {                                          \
      if (flag[i])                                                             \
        continue;                                                              \
      T v = value[i];                                                          \
      if (isnan(v))                                                            \
        continue;                                                              \
      if (v == 0) {                                                            \
        /* get rid of negative 0*/                                             \
        v = 0;                                                                 \
      }                                                                        \
      minval = (v < minval) ? v : minval;                                      \
      maxval = (v > maxval) ? v : maxval;                                      \
      xrg_bloom_add(bloom, &v, sizeof(T));                                     \
    }                                                                          \
    *(T *)&rec->minval = minval;                                               \
    *(T *)&rec->maxval = maxval;                                               \
  }

static __int128_t get_int128_max() {
  static __int128_t saved = 0;
  if (!saved) {
    __int128_t v = INT64_MAX;
    v <<= 64;
    v |= (uint64_t)-1; /* note: must use uint64_t to prevent sign-extension */
    saved = v;
  }
  return saved;
}

static int process_interval(xrg_zonerec_t *rec, int nitem, const char *data,
                            const char *flag, char *errbuf, int errbuflen) {
  __int128_t *span = malloc(nitem * sizeof(__int128_t));
  if (!span) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    return -1;
  }

  const xrg_interval_t *value = (const xrg_interval_t *)data;
  for (int i = 0; i < nitem; i++) {
    span[i] = value[i].mon * 30 + value[i].day;
    span[i] *= 24 * 60 * 60 * 1000 * (int64_t)1000;
    span[i] += value[i].usec;
  }

  const __int128_t INT128_MAX = get_int128_max();
  const __int128_t INT128_MIN = -INT128_MAX - 1;
  process_fixed_int(__int128_t, INT128_MIN, INT128_MAX, &rec->bloom);
  free(span);

  return 0;
}

static int process_int(xrg_zonerec_t *rec, int nitem, const char *data,
                       const char *flag, char *errbuf, int errbuflen) {
  xrg_bloom_t *bloom = &rec->bloom;
  switch (rec->ptyp) {
  case XRG_PTYP_INT8:
    process_fixed_int(int8_t, INT8_MIN, INT8_MAX, bloom);
    break;
  case XRG_PTYP_INT16:
    process_fixed_int(int16_t, INT16_MIN, INT16_MAX, bloom);
    break;
  case XRG_PTYP_INT32:
    process_fixed_int(int32_t, INT32_MIN, INT32_MAX, bloom);
    break;
  case XRG_PTYP_INT64:
    process_fixed_int(int64_t, INT64_MIN, INT64_MAX, bloom);
    break;
  case XRG_PTYP_INT128: {
    const __int128_t INT128_MAX = get_int128_max();
    const __int128_t INT128_MIN = -INT128_MAX - 1;
    process_fixed_int(__int128_t, INT128_MIN, INT128_MAX, bloom);
    break;
  }
  default:
    snprintf(errbuf, errbuflen,
             "xrg_zonemap: process_int: ptyp %s is not handled",
             xrg_ptyp_to_string(rec->ptyp));
    return -1;
  }

  return 0;
}

static int process_fp(xrg_zonerec_t *rec, int nitem, const char *data,
                      const char *flag, char *errbuf, int errbuflen) {
  xrg_bloom_t *bloom = &rec->bloom;
  switch (rec->ptyp) {
  case XRG_PTYP_FP32:
    process_fixed_fp(float, FLT_MIN, FLT_MAX, bloom);
    break;
  case XRG_PTYP_FP64:
    process_fixed_fp(double, DBL_MIN, DBL_MAX, bloom);
    break;
  default:
    snprintf(errbuf, errbuflen,
             "xrg_zonemap: process_fp: ptyp %s is not handled",
             xrg_ptyp_to_string(rec->ptyp));
    return -1;
  }

  return 0;
}

static inline __attribute__((always_inline)) int
varstr_cmp(const char *S1, int L1, const char *S2, int L2) {
  int len = (L1 < L2 ? L1 : L2);
  int res = memcmp(S1, S2, len);
  if (res == 0 && L1 != L2)
    res = (L1 < L2) ? -1 : 1;
  return res;
}

static int process_string(xrg_zonerec_t *rec, int nitem, const char *data,
                          const char *flag, char *errbuf, int errbuflen) {
  assert(rec->ltyp == XRG_LTYP_STRING);
  if (rec->ptyp != XRG_PTYP_BYTEA) {
    snprintf(errbuf, errbuflen,
             "xrg_zonemap: process_string: ptyp %s is not handled",
             xrg_ptyp_to_string(rec->ptyp));
    return -1;
  }

  char empty[5];
  xrg_bytea_encode(empty, "", 0);

  const char *Vmin = 0;
  int Lmin = 0;
  const char *Vmax = 0;
  int Lmax = 0;

  xrg_bloom_t *bloom = &rec->bloom;

  // populate default value of Vmin & Vmax with first proper value
  const char *p = data;
  for (int i = 0; i < nitem; i++) {
    const char *val = xrg_bytea_ptr(p);
    int len = xrg_bytea_len(p);
    p = val + len;

    if (flag[i])
      continue;

    Vmin = Vmax = val;
    Lmin = Lmax = len;
    break;
  }

  // if there are no non-null items, default to empty string.
  if (!Vmin) {
    Vmin = Vmax = xrg_bytea_ptr(empty);
    Lmin = Lmax = xrg_bytea_len(empty);
  }

  // scan all items to determine min/max
  p = data;
  for (int i = 0; i < nitem; i++) {
    const char *val = xrg_bytea_ptr(p);
    int len = xrg_bytea_len(p);
    p = val + len;

    if (flag[i])
      continue;

    if (varstr_cmp(Vmin, Lmin, val, len) > 0) {
      // Vmin > val
      Vmin = val;
      Lmin = len;
    } else if (varstr_cmp(Vmax, Lmax, val, len) < 0) {
      // Vmax < val
      Vmax = val;
      Lmax = len;
    }

    xrg_bloom_add(bloom, val, len);
  }

  // cutoff at 128
  Lmin = (Lmin > 128) ? 128 : Lmin;
  Lmax = (Lmax > 128) ? 128 : Lmax;

  // save to rec->minval rec->maxval
  xrg_bytea_encode(rec->minval, Vmin, Lmin);
  xrg_bytea_encode(rec->maxval, Vmax, Lmax);

  return 0;
}

static int process_array(xrg_zonerec_t *rec, int nitem, const char *data,
                         const char *flag, char *errbuf, int errbuflen) {
  (void)nitem;
  (void)data;
  (void)flag;
  assert(rec->ltyp == XRG_LTYP_ARRAY);
  if (rec->ptyp != XRG_PTYP_BYTEA) {
    snprintf(errbuf, errbuflen,
             "xrg_zonemap: process_array: ptyp %s is not handled",
             xrg_ptyp_to_string(rec->ptyp));
    return -1;
  }

  rec->invalid = 1;
  return 0;
}

// Create the zonemap at rgidx using vbuf
static int process(xrg_zonerec_t *rec, const char *cname, int32_t rgidx,
                   int nfield, const xrg_vector_t *vbuf, char *errbuf,
                   int errbuflen) {
  const int nitem = vbuf->header.nitem;
  memcpy(rec->magic, XRG_ZONEMAP_MAGIC, 8);
  memcpy(rec->magic2, XRG_ZONEMAP_MAGIC, 8);
  strncpy(rec->cname, cname, sizeof(rec->cname));
  rec->cname[sizeof(rec->cname) - 1] = 0;
  rec->rgidx = rgidx;
  rec->nfield = nfield;
  rec->fieldidx = vbuf->header.fieldidx;
  rec->ptyp = vbuf->header.ptyp;
  rec->ltyp = vbuf->header.ltyp;
  rec->scale = vbuf->header.scale;
  rec->precision = vbuf->header.precision;
  rec->itemsz = vbuf->header.itemsz;
  rec->nitem = vbuf->header.nitem;
  rec->invalid = 0;

  const char *data = XRG_VECTOR_DATA(vbuf);
  const char *flag = XRG_VECTOR_FLAG(vbuf);

  // fill-in has_null, has_nonnull
  int hasnull = 0;
  int hasnonnull = 0;
  for (int i = 0; i < nitem; i++) {
    int x = flag[i] & XRG_FLAG_NULL;
    hasnull |= (!!x);
    hasnonnull |= !x;
  }
  rec->hasnull = (char)hasnull;
  rec->hasnonnull = (char)hasnonnull;

  // fill-in min, max, bloomfilter
  xrg_bloom_init(&rec->bloom);

  switch (XRG_LTYP_PTYP(rec->ltyp, rec->ptyp)) {
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT8):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT16):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT32):
  case XRG_LTYP_PTYP(XRG_LTYP_DATE, XRG_PTYP_INT32):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT64):
  case XRG_LTYP_PTYP(XRG_LTYP_TIME, XRG_PTYP_INT64):
  case XRG_LTYP_PTYP(XRG_LTYP_TIMESTAMP, XRG_PTYP_INT64):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT128):
  case XRG_LTYP_PTYP(XRG_LTYP_DECIMAL, XRG_PTYP_INT64):
  case XRG_LTYP_PTYP(XRG_LTYP_DECIMAL, XRG_PTYP_INT128):
    return process_int(rec, nitem, data, flag, errbuf, errbuflen);

  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_FP32):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_FP64):
    return process_fp(rec, nitem, data, flag, errbuf, errbuflen);

  case XRG_LTYP_PTYP(XRG_LTYP_STRING, XRG_PTYP_BYTEA):
    return process_string(rec, nitem, data, flag, errbuf, errbuflen);

  case XRG_LTYP_PTYP(XRG_LTYP_INTERVAL, XRG_PTYP_INT128):
    return process_interval(rec, nitem, data, flag, errbuf, errbuflen);

  case XRG_LTYP_PTYP(XRG_LTYP_ARRAY, XRG_PTYP_BYTEA):
    return process_array(rec, nitem, data, flag, errbuf, errbuflen);
  }

  snprintf(errbuf, errbuflen, "xrg_zonemap: process: ltyp %s is not handled",
           xrg_ltyp_to_string(rec->ltyp));
  return -1;
}

struct xrg_zmwriter_t {
  int fd;
  int nfield;
  int32_t next_rgidx;
  char **cname;
  xrg_zonerec_t rec[1];
};

int xrg_zmwriter_add(xrg_zmwriter_t *zmw, int32_t rgidx, xrg_vector_t **vbuf,
                     char *errbuf, int errbuflen) {

  if (rgidx != zmw->next_rgidx) {
    snprintf(errbuf, errbuflen,
             "xrg_zmwriter_add: expecting rgidx %d, but got %d",
             zmw->next_rgidx, rgidx);
    return -1;
  }

  int nfield = zmw->nfield;
  for (int i = 0; i < nfield; i++) {
    if (xrg_vector_is_compressed(vbuf[i])) {
      snprintf(errbuf, errbuflen, "xrg_zmwriter_add: vbuf[%d] is compressed",
               i);
      return -1;
    }
  }

  if (rgidx > 0) {
    // check that the type of each field match those of previous rowgroup
    for (int i = 0; i < nfield; i++) {
      if (zmw->rec[i].ltyp != vbuf[i]->header.ltyp ||
          zmw->rec[i].ptyp != vbuf[i]->header.ptyp ||
          zmw->rec[i].scale != vbuf[i]->header.scale ||
          zmw->rec[i].precision != vbuf[i]->header.precision) {
        snprintf(errbuf, errbuflen,
                 "xrg_zmwriter_add: type mismatch for vbuf[%d]", i);
        return -1;
      }
    }
  }

  // compute each zonemap
  for (int i = 0; i < nfield; i++) {
    if (vbuf[i]->header.fieldidx != i) {
      snprintf(
          errbuf, errbuflen,
          "xrg_zmwriter_add: vbuf[%d] should contain fieldidx %d, but got %d",
          i, i, vbuf[i]->header.fieldidx);
      return -1;
    }
    if (process(&zmw->rec[i], zmw->cname[i], rgidx, nfield, vbuf[i], errbuf,
                errbuflen)) {
      return -1;
    }
  }

  // write the rec
  for (int i = 0; i < zmw->nfield; i++) {
    xrg_zonerec_t *rec = &zmw->rec[i];
    if (xrg_writefully(zmw->fd, rec, sizeof(*rec), errbuf, errbuflen)) {
      return -1;
    }
  }

  zmw->next_rgidx++;
  return 0;
}

xrg_zmwriter_t *xrg_zmwriter_open(const char *fname, int nfield,
                                  const char **cname, char *errbuf,
                                  int errbuflen) {
  if (nfield < 0) {
    snprintf(errbuf, errbuflen, "%s", "xrg_zmwriter_open: invalid nfield");
    return 0;
  }

  xrg_zmwriter_t *zmw = 0;
  int zmw_size = (int)(intptr_t)&zmw->rec[nfield];
  zmw = calloc(1, zmw_size);
  if (!zmw) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    goto bail;
  }

  zmw->fd = open(fname, O_CREAT | O_WRONLY | O_TRUNC, 0600);
  if (zmw->fd == -1) {
    snprintf(errbuf, errbuflen, "%s", strerror(errno));
    goto bail;
  }

  zmw->nfield = nfield;
  zmw->next_rgidx = 0;

  zmw->cname = calloc(nfield, sizeof(char *));
  if (!zmw->cname) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    goto bail;
  }

  /* allocate cname[].
   */
  for (int i = 0; i < nfield; i++) {
    zmw->cname[i] = strdup(cname[i]);
    if (!zmw->cname[i]) {
      snprintf(errbuf, errbuflen, "%s", "out of memory");
      goto bail;
    }
    if (strlen(zmw->cname[i]) > 63) {
      snprintf(errbuf, errbuflen, "cname[%d] is too long (max 63)", i);
      goto bail;
    }
  }

  return zmw;

bail:
  if (zmw) {
    unlink(fname);
    xrg_zmwriter_close(zmw);
  }
  return 0;
}

void xrg_zmwriter_close(xrg_zmwriter_t *zmw) {
  if (zmw) {
    if (zmw->fd >= 0) {
      close(zmw->fd);
    }
    if (zmw->cname) {
      for (int i = 0; i < zmw->nfield; i++) {
        free(zmw->cname[i]);
      }
      free(zmw->cname);
    }
    free(zmw);
  }
}
