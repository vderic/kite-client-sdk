#include "xrg_int.h"
#ifdef __ARM_NEON__
#include "sse2neon.h"
#else
#include <nmmintrin.h>
#endif

xrg_crc32c_t xrg_crc32c_init(const void *data, int len) {
  return xrg_crc32c_mix(0xFFFFFFFF, data, len);
}

xrg_crc32c_t xrg_crc32c_mix(xrg_crc32c_t c, const void *data, int len) {
  const char *p = data;
  const char *const q = data + len;

  for (; p + 8 <= q; p += 8) {
    // 8-byte at a time
    c = (xrg_crc32c_t)_mm_crc32_u64(c, *(const uint64_t *)p);
  }

  for (; p < q; p++) {
    c = _mm_crc32_u8(c, *p);
  }

  return c;
}
