#include "harness.h"
#include <stdio.h>
#include <stdlib.h>

// Test zonemaps
int main() {

#ifdef NDEBUG
  fprintf(stderr, "warning: running in NON-DEBUG...\n");
#endif

  char errbuf[100];
  const int errbuflen = sizeof(errbuf);
  char *cname[8] = {"a", "b", "c", "d", "e", "f", "g", "h"};
  xrg_vecbuf_t *vbuf[8];
  vbuf[0] = xrg_vecbuf_create(XRG_PTYP_INT8, XRG_LTYP_NONE, 0, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[0]);
  vbuf[1] = xrg_vecbuf_create(XRG_PTYP_INT16, XRG_LTYP_NONE, 1, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[1]);
  vbuf[2] = xrg_vecbuf_create(XRG_PTYP_INT32, XRG_LTYP_NONE, 2, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[2]);
  vbuf[3] = xrg_vecbuf_create(XRG_PTYP_INT64, XRG_LTYP_NONE, 3, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[3]);
  vbuf[4] = xrg_vecbuf_create(XRG_PTYP_INT128, XRG_LTYP_NONE, 4, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[4]);
  vbuf[5] = xrg_vecbuf_create(XRG_PTYP_FP32, XRG_LTYP_NONE, 5, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[5]);
  vbuf[6] = xrg_vecbuf_create(XRG_PTYP_FP64, XRG_LTYP_NONE, 6, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[6]);
  vbuf[7] = xrg_vecbuf_create(XRG_PTYP_BYTEA, XRG_LTYP_STRING, 7, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[7]);

  for (int j = 0; j < 1000; j++) {
    char flag[10] = {0};
    int8_t i8[10];
    int16_t i16[10];
    int32_t i32[10];
    int64_t i64[10];
    __int128_t i128[10];
    float fp32[10];
    double fp64[10];
    char str[10][10];
    char *sptr[10];
    int slen[10];

    for (int i = 0; i < 10; i++) {
      i8[i] = i;
      i16[i] = i;
      i32[i] = i;
      i64[i] = i;
      i128[i] = i;
      fp32[i] = i;
      fp64[i] = i;
      sprintf(str[i], "%d%d%d%d", i, i, i, i);
      sptr[i] = str[i];
      slen[i] = strlen(sptr[i]);
    }

    CHECK(0 ==
          xrg_vecbuf_append_int8(vbuf[0], 10, i8, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int16(vbuf[1], 10, i16, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int32(vbuf[2], 10, i32, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int64(vbuf[3], 10, i64, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int128(vbuf[4], 10, i128, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_fp32(vbuf[5], 10, fp32, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_fp64(vbuf[6], 10, fp64, flag, errbuf, errbuflen));
    CHECK(0 == xrg_vecbuf_append_bytea(vbuf[7], 10, sptr, slen, flag, errbuf,
                                       errbuflen));
  }

  xrg_vector_t *vector[8];
  for (int i = 0; i < 8; i++) {
    vector[i] = xrg_vector_from_vecbuf(vbuf[i], errbuf, errbuflen);
    CHECK(vector[i]);
  }

  // create the zonemap
  const char *OUTFILE = "test5.zmp";
  xrg_zmwriter_t *zmw =
      xrg_zmwriter_open(OUTFILE, 8, (const char **)cname, errbuf, errbuflen);
  CHECK(zmw);

  CHECK(0 == xrg_zmwriter_add(zmw, 0, vector, errbuf, errbuflen));
  CHECK(0 == xrg_zmwriter_add(zmw, 1, vector, errbuf, errbuflen));

  xrg_zmwriter_close(zmw);

  /* scan the whole zonemap */
  xrg_zonemap_t *zmap = xrg_zonemap_open(OUTFILE, errbuf, errbuflen);
  CHECK(zmap);
  for (int rgidx = 0; rgidx < 2; rgidx++) {
    for (int fidx = 0; fidx < 8; fidx++) {
      xrg_zonerec_t *rec =
          xrg_zonemap_read(zmap, rgidx, fidx, errbuf, errbuflen);
      CHECK(rec);
      CHECK(rec->rgidx == rgidx);
      CHECK(rec->fieldidx == fidx);
      CHECK(rec->ltyp == vbuf[fidx]->header.ltyp);
      CHECK(rec->ptyp == vbuf[fidx]->header.ptyp);

      // do some simple check
      if (fidx == 2) {
        int32_t v = *(int32_t *)rec->minval;
        CHECK(v == 0);
        v = *(int32_t *)rec->maxval;
        CHECK(v == 9);
        CHECK(!rec->hasnull);
        CHECK(rec->hasnonnull);
        for (int i = 0; i < 10; i++) {
          v = i;
          CHECK(xrg_bloom_isset(&rec->bloom, &v, sizeof(v)));
        }
        v = -1;
        CHECK(!xrg_bloom_isset(&rec->bloom, &v, sizeof(v)));
      } else if (fidx == 5) {
        float v = *(float *)rec->minval;
        CHECK(v == 0);
        v = *(float *)rec->maxval;
        CHECK(v == 9);
        CHECK(!rec->hasnull);
        CHECK(rec->hasnonnull);
        for (int i = 0; i < 10; i++) {
          v = i;
          CHECK(xrg_bloom_isset(&rec->bloom, &v, sizeof(v)));
        }
        v = -1;
        CHECK(!xrg_bloom_isset(&rec->bloom, &v, sizeof(v)));
      } else if (fidx == 7) {
        const char *val = xrg_bytea_ptr(rec->minval);
        int len = xrg_bytea_len(rec->minval);
        CHECK(4 == len && 0 == memcmp(val, "0000", len));
        val = xrg_bytea_ptr(rec->maxval);
        len = xrg_bytea_len(rec->maxval);
        CHECK(4 == len && 0 == memcmp(val, "9999", len));

        for (int i = 0; i < 10; i++) {
          char buf[5];
          sprintf(buf, "%d%d%d%d", i, i, i, i);
          CHECK(xrg_bloom_isset(&rec->bloom, buf, 4));
        }
        CHECK(!xrg_bloom_isset(&rec->bloom, "blasphemy", 9));
      }
    }
  }
  xrg_zonemap_close(zmap);

  /* clean up */
  for (int i = 0; i < 8; i++) {
    xrg_vecbuf_release(vbuf[i]);
  }
  return 0;
}
