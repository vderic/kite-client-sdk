mkdir -p out
for index in {1..100}; do
    F=test$index
    [ -f $F ] || continue
    echo $F
    ./$F > out/$F.out 
    diff good/$F.out out/ || { echo '--- FAILED ---'; exit 1; }
done
