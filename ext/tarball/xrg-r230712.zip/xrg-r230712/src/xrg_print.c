/// \file
/// \brief XRG printing routings

#define _POSIX_C_SOURCE 1
#include "xrg_int.h"
#include <assert.h>
#include <errno.h>
#include <inttypes.h>
#include <stdlib.h>
#include <time.h>

// clang-format off
#define CHECK(x)  if (x); else return -1
#define CHECKBAIL(x) if (x); else goto bail
#define CHECKP(x) if (x); else return NULL
// clang-format on

typedef struct print_context_t print_context_t;
struct print_context_t {
  const xrg_vechdr_t *header;
  char delim;
};

typedef void (*printfn_t)(FILE *fp, const void *value,
                          const print_context_t *ctx);

static void print_int8(FILE *fp, const void *value,
                       const print_context_t *ctx) {
  (void)ctx;
  fprintf(fp, "%d", *(const int8_t *)value);
}

static void print_int16(FILE *fp, const void *value,
                        const print_context_t *ctx) {
  (void)ctx;
  fprintf(fp, "%d", *(const int16_t *)value);
}

static void print_int32(FILE *fp, const void *value,
                        const print_context_t *ctx) {
  (void)ctx;
  fprintf(fp, "%d", *(const int32_t *)value);
}

static void print_int64(FILE *fp, const void *value,
                        const print_context_t *ctx) {
  (void)ctx;
  fprintf(fp, "%" PRId64, *(const int64_t *)value);
}

static void print_int128(FILE *fp, const void *value,
                         const print_context_t *ctx) {
  (void)ctx;
  char buffer[128];
  __int128_t val = *(__int128_t *)value;
  __uint128_t tmp = (val < 0) ? -val : val;
  char *p = &buffer[sizeof(buffer) - 1];
  *p = 0;
  do {
    *--p = '0' + (tmp % 10);
    tmp /= 10;
  } while (tmp);
  if (val < 0) {
    *--p = '-';
  }
  fprintf(fp, "%s", p);
}

static void print_fp32(FILE *fp, const void *value,
                       const print_context_t *ctx) {
  (void)ctx;
  fprintf(fp, "%.2f", *(const float *)value);
}

static void print_fp64(FILE *fp, const void *value,
                       const print_context_t *ctx) {
  (void)ctx;
  fprintf(fp, "%.2f", *(const double *)value);
}

static void print_string(FILE *fp, const void *value,
                         const print_context_t *ctx) {
  const int32_t len = xrg_bytea_len(value);
  const char *ptr = xrg_bytea_ptr(value);
  const int delim = ctx->delim;
  int need_quote = 0;

  // check if quote is needed
  for (int i = 0; i < len && !need_quote; i++) {
    int ch = ptr[i];
    need_quote |= (ch == '"');
    need_quote |= (ch == '\n');
    need_quote |= (ch == delim);
  }

  // speed up the usual case
  if (!need_quote) {
    fwrite(ptr, 1, len, fp);
    return;
  }

  fputc('"', fp);
  for (int i = 0; i < len; i++) {
    int ch = ptr[i];
    if (ch == '"') {
      fputc('"', fp);
    }
    fputc(ch, fp);
  }
  fputc('"', fp);
}

static void print_decimal(FILE *fp, __int128 value, int precision, int scale) {
  // DECIMAL: Formula: unscaledValue * 10^(-scale)
  // int32: max precision is 9.
  // int64: max precision is 18.
  // int128: max precision is 38.
  // int256: max precision is 76. (not supported).

  assert(precision >= 1 && precision <= 38);
  assert(scale >= 0 && scale < precision);
  const int sign = (value < 0);
  __uint128_t tmp = (sign ? -value : value);

  char buffer[128];
  char *p = &buffer[sizeof(buffer) - 1];
  *p = 0;

  for (; scale > 0; scale--, precision--) {
    *--p = '0' + (tmp % 10);
    tmp /= 10;
  }

  if (*p) {
    *--p = '.';
  }

  for (; precision > 0 && tmp; precision--) {
    *--p = '0' + (tmp % 10);
    tmp /= 10;
  }

  if (*p == '.' || *p == 0) {
    *--p = '0';
  }

  if (sign) {
    *--p = '-';
  }
  fprintf(fp, "%s", p);
}

static void print_decimal64(FILE *fp, const void *value,
                            const print_context_t *ctx) {
  __int128 t = *(const int64_t *)(value);
  print_decimal(fp, t, ctx->header->precision, ctx->header->scale);
}

static void print_decimal128(FILE *fp, const void *value,
                             const print_context_t *ctx) {
  print_decimal(fp, *(const __int128 *)value, ctx->header->precision,
                ctx->header->scale);
}

static void print_date(FILE *fp, const void *value,
                       const print_context_t *ctx) {
  (void)ctx;
  char buf[20];
  char *s = xrg_date_str(*(const int32_t *)value, buf, sizeof(buf));
  fputs(s ? s : "???", fp);
}

static void print_time(FILE *fp, const void *value,
                       const print_context_t *ctx) {
  (void)ctx;
  char buf[20];
  char *s = xrg_time_str(*(const int64_t *)value, buf, sizeof(buf));
  fputs(s ? s : "???", fp);
}

static void print_timestamp(FILE *fp, const void *value,
                            const print_context_t *ctx) {
  (void)ctx;
  char buf[40];
  char *s = xrg_timestamp_str(*(const int64_t *)value, buf, sizeof(buf));
  fputs(s ? s : "???", fp);
}

static void print_interval(FILE *fp, const void *value,
                           const print_context_t *ctx) {
  (void)ctx;
  char buf[100];
  char *s = xrg_interval_str(*(const xrg_interval_t *)value, buf, sizeof(buf));
  fputs(s ? s : "???", fp);
}

static printfn_t get_printfn(int16_t ptyp, int16_t ltyp, char *errbuf,
                             int errbuflen);

static void print_array(FILE *fp, const void *value,
                        const print_context_t *ctx) {
  char buf[100];
  xrg_array_header_t *arr = (xrg_array_header_t *)value;

  int ndim = xrg_array_ndim(arr);
  int16_t ptyp = xrg_array_ptyp(arr);
  int16_t ltyp = xrg_array_ltyp(arr);
  int32_t *dims = xrg_array_dims(arr);
  char *data = xrg_array_data_ptr(arr);
  int itemsz = xrg_itemsz(ptyp, ltyp, ctx->header->precision, buf, sizeof(buf));
  if (itemsz == 0) {
    fputs(buf, fp);
    return;
  }

  printfn_t fn = get_printfn(ptyp, ltyp, buf, sizeof(buf));
  if (fn == 0) {
    fputs(buf, fp);
    return;
  }

  char *p = data;
  for (int i = 0; i < ndim; i++) {
    fputc('{', fp);
    for (int j = 0; j < dims[i]; j++) {
      if (j > 0) {
        fputc(',', fp);
      }
      fn(fp, p, ctx);
      if (itemsz > 0) {
        p += itemsz;
      } else {
        p += xrg_bytea_len(p) + 4;
      }
    }
    fputc('}', fp);
  }
}

static printfn_t get_printfn(int16_t ptyp, int16_t ltyp, char *errbuf,
                             int errbuflen) {
  switch (XRG_LTYP_PTYP(ltyp, ptyp)) {
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT8):
    return print_int8;
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT16):
    return print_int16;
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT32):
    return print_int32;
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT64):
    return print_int64;
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT128):
    return print_int128;
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_FP32):
    return print_fp32;
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_FP64):
    return print_fp64;
  case XRG_LTYP_PTYP(XRG_LTYP_STRING, XRG_PTYP_BYTEA):
    return print_string;
  case XRG_LTYP_PTYP(XRG_LTYP_DECIMAL, XRG_PTYP_INT64):
    return print_decimal64;
  case XRG_LTYP_PTYP(XRG_LTYP_DECIMAL, XRG_PTYP_INT128):
    return print_decimal128;
  case XRG_LTYP_PTYP(XRG_LTYP_DATE, XRG_PTYP_INT32):
    return print_date;
  case XRG_LTYP_PTYP(XRG_LTYP_TIME, XRG_PTYP_INT64):
    return print_time;
  case XRG_LTYP_PTYP(XRG_LTYP_TIMESTAMP, XRG_PTYP_INT64):
    return print_timestamp;
  case XRG_LTYP_PTYP(XRG_LTYP_INTERVAL, XRG_PTYP_INT128):
    return print_interval;
  case XRG_LTYP_PTYP(XRG_LTYP_ARRAY, XRG_PTYP_BYTEA):
    return print_array;
  default:
    snprintf(errbuf, errbuflen, "unsupported XRG_LTYP_PTYP combination (%d,%d)",
             ltyp, ptyp);
    return 0;
  }
  return 0;
}

static int create_printfn(printfn_t pfn[], int nvec,
                          const xrg_vector_t *const *vec, char *errbuf,
                          int errbuflen) {
  for (int i = 0; i < nvec; i++) {
    int ltyp = vec[i]->header.ltyp;
    int ptyp = vec[i]->header.ptyp;
    pfn[i] = get_printfn(ptyp, ltyp, errbuf, errbuflen);
    if (!pfn[i]) {
      snprintf(errbuf, errbuflen,
               "unsupported XRG_LTYP_PTYP combination (%d,%d)", ltyp, ptyp);
      return -1;
    }
  }
  return 0;
}

int xrg_vector_print(FILE *fp, int nvec, const xrg_vector_t **vec_, char delim,
                     const char *nullstr, char *errbuf, int errbuflen) {
  xrg_iter_t *it = 0;
  const xrg_vector_t **vec = calloc(nvec, sizeof(*vec));
  printfn_t *pfn = calloc(nvec, sizeof(*pfn));
  print_context_t *ctxs = calloc(nvec, sizeof(*ctxs));
  int bailed = 0;
  if (!(vec && pfn && ctxs)) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    goto bail;
  }

  int nitem = nvec ? vec_[0]->header.nitem : 0;

  /* check all vectors */
  for (int col = 0; col < nvec; col++) {
    /* ... same nitem */
    if (vec_[col]->header.nitem != nitem) {
      snprintf(errbuf, errbuflen, "vecbuf %d: nitem mismatch", col);
      goto bail;
    }
    /* ... not compressed */
    if (xrg_vector_is_compressed(vec_[col])) {
      vec[col] = xrg_vector_uncompress(vec_[col], errbuf, errbuflen);
      CHECKBAIL(0 != vec[col]);
    } else {
      vec[col] = vec_[col];
    }
  }

  CHECKBAIL(0 == create_printfn(pfn, nvec, vec, errbuf, errbuflen));

  for (int col = 0; col < nvec; col++) {
    ctxs[col] = (print_context_t){.header = &vec[col]->header, .delim = delim};
  }

  /* for each row, print it */
  it = xrg_iter_create(nvec, vec, errbuf, errbuflen);
  CHECKBAIL(it);

  for (int row = 0; 0 == xrg_iter_next(it); row++) {

    for (int col = 0; col < nvec; col++) {
      // print delim if this is not col 0.
      if (col > 0) {
        fputc(delim, fp);
      }
      // print this field
      if (0 != (xrg_iter_flag(it, col) & XRG_FLAG_NULL)) {
        fputs(nullstr, fp);
      } else {
        (pfn[col])(fp, xrg_iter_value(it, col), &ctxs[col]);
      }
    }
    fputc('\n', fp);

    // Is the stream still valid? Check once per 256 rows.
    if ((row & 0xff) == 0xff && ferror(fp)) {
      snprintf(errbuf, errbuflen, "cannot write file - %s", strerror(errno));
      goto bail;
    }
  }

  goto cleanup;

bail:
  bailed = 1;

cleanup:
  for (int i = 0; i < nvec; i++) {
    if (vec[i] != vec_[i]) {
      // we allocated this vector (probably because we needed to uncompress
      // vec_[i]), so we are responsible for freeing it.
      xrg_vector_release((xrg_vector_t *)vec[i]);
    }
  }
  free(vec);
  free(pfn);
  free(ctxs);
  xrg_iter_release(it);

  return bailed ? -1 : 0;
}
