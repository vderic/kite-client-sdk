#ifndef XRG_INT_H
#define XRG_INT_H

#include "xrg.h"

typedef struct xrg_footer_t xrg_footer_t;
struct xrg_footer_t {
  int32_t nvec;
  char magic[4];
};

int xrg_itemsz(int ptyp, int ltyp, int precision, char *errbuf, int errbuflen);
int xrg_readfully(int fd, void *buf, int bufsz, char *errbuf, int errbuflen);
int xrg_writefully(int fd, const void *buf, int bufsz, char *errbuf,
                   int errbuflen);
int64_t xrg_filesize(int fd, char *errbuf, int errbuflen);
int xrg_readfully_at(int fd, int64_t offset, void *buf, int bufsz, char *errbuf,
                     int errbuflen);

const char *xrg_ptyp_to_string(int ptyp);
const char *xrg_ltyp_to_string(int ltyp);

#endif /* XRG_INT_H */
