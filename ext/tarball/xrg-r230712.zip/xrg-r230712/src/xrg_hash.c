#include "komihash.h"
#include "xrg.h"

uint64_t xrg_hash(uint64_t seed, const void *data, int len) {
  return komihash(data, len, seed);
}
