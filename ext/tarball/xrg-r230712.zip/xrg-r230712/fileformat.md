# File formats

There are 4 types of files involved.

1. XRG files
2. ZMP file
3. list.json file
4. schema.json file

## XRG File

For an original parquet file T.par or a csv file T.csv, many xrg files
will be created. Each xrg file will store a row-group. A row-group is
simply a group of C rows, where C could be as large as 10,000.

Thus, for a parquet or csv file T.{par,csv}, we will create:

1. N files named `T_{n}.xrg`, where n is the rowgroup ID.
2. a zonemap file named `T.zmp` to index on field ranges. It returns
eligible {n} given some filter conditions.
3. one inventory file named `T.lst` that lists the full path of all
`T_{n}.xrg` files.


### Defines

    #define FLAG_ISNULL   0x01
    #define FLAG_INVAL  0x02


    #define MAGIC 0xAC83DE01   <<<< change to "XRG1"

    #define PHY_INT8   0x1
    #define PHY_INT16  0x2
    #define PHY_INT32  0x3
    #define PHY_INT64  0x4
    #define PHY_INT128 0x5
    #define PHY_FP32   0x6
    #define PHY_FP64   0x7
    #define PHY_BYTEA  0x8

    #define LGC_RAW       0x0   <<<< change to LGC_NONE  0x1
    #define LGC_INT       0x1   <<<< delete
    #define LGC_STRING    0x2
    #define LGC_DECIMAL   0x3
    #define LGC_INTERVAL  0x4
    #define LGC_TIME      0x5
    #define LGC_DATE      0x6
    #define LGC_TIMESTAMP 0x7
    #define LGC_TIMESTAMPTZ 0x8   <<<< delete

### Vectors in XRG File

There are three types of vectors:
1. FV - fixed-size data type vector
2. VV - variable-size data type vector
3. DV - directory vector

An XRG file is composed of arrays of FV or VV, concatenated one after
another, ending with a DV. All FV or VV shall be of the same
cardinality, i.e., they store the same number of elements. The
DV shall store the offsets of the FV/VV in the file.


#### FV Format

    header (48 bytes):
        char magic[4];
        int16_t physical-data-type
        int16_t logical-data-type
        int16_t cno       // column number
        int16_t itemsz    // #byte per item
        int16_t scale     // for decimal type
        int16_t precision // for decimal type
        int32_t nbyte   // uncompressed #bytes of the data[]
        int32_t zbyte   // compressed #bytes of the data[]
        int32_t nnull     // number of null value
        int32_t #items
        int64_t unused    <<<< change to (int32_t ninval; int32_t unused1)
        int64_t unused
    body:
        int8_t data[#byte];  // aligned 16
        int8_t flag[#item];  // not aligned
        int8_t padding[x];   // pad to 16-byte boundary


#### VV Format


    header (40 bytes):
        char magic[5];
        int16_t physical-data-type
        int16_t logical-data-type
        int16_t cno       // column number
        int16_t itemsz    // #byte per item
        int16_t scale     // for decimal type
        int16_t precision // for decimal type
        int32_t nbyte     // uncompressed #bytes of the data[]
        int32_t zbyte     // compressed #bytes of the data[]
        int32_t nnull     // number of null value
        int32_t #items
	int64_t unused    <<<< change to (int32_t ninval; int32_t unused1)
	int64_t unused
    body:
        int8_t data[#byte];     // aligned 16
        int8_t flag[#item];     // not aligned
        int8_t padding[x];      // pad to 16-byte boundary


Bytea data item is always prefixed by a 4-byte length field. The
maximum length of a bytea is 1GB (i.e. 2^30). For the common short
strings less than 128-byte in length, this is slightly inefficient
storage-wise. However, in the larger scheme of things, since xrg will
compress string data prior to storage, these length words with lots of
'0' value will be mostly compressed away. We therefore opted to reap
the benefit of CPU efficiency by using a simple encoding algorithm,
and pay a very small price in storage.

    static inline uint32_t bytea_len(void *encoded) {   <<<< changed
      return *(uint32_t*) encoded;
    }

    static inline char *bytea_ptr(void *encoded) {   <<<< changed
      return ((char*)encoded) + 4;
    }

    static inline char *bytea_encode(char *dst, void *src, int len) { <<<< changed
      assert(len <= (1<<30));
      *(int32_t*) dst = len;
      memcpy(dst + 4, src, len);
    }


#### DV Format

    body:
        int64_t offset[#vectors]

    footer:
        int32_t #vectors 	<<< Eric swapped the two fields. Pls swap it back to this format.
        char magic[4]

#### Note

1. DV is never compressed.
2. For FV and VV, the header is never compressed, while the body may
be compressed.
3. The body is compressed if zbyte < nbyte. The body is not compressed
if zbyte == nbyte.
4. Only the data[] in the body can be compressed.
5. To read a file, first read the last 8 bytes of the file. It should
match the footer.
6. From the footer, we can index into offset[] and get to each vector.


#### Logical Data Format

#### Interval

Interval is used for an interval of time.  It must annote a
```int128```.  This stores two little-endian unsigned ```int32``` and
one little-endian unsigned ```int64``` that represent durations at
different granularities of time.  The first 64 bits stores a number in
microseconds, the 65th-96th bits stores a number in days, and the
97th-128th bits stores a number in months.  This representation is
independent of any particular timezone or date.

Each component in this representation is independent of the others.
For example, there is no requirement that a large number of days
should be expressed as a mix of months and days because there is not a
constant conversion from days to months.

In postgresql, the following queries are both true:
```
SELECT INTERVAL '1 month' = INTERVAL '30 days';
SELECT INTERVAL '1 day' = INTERVAL '86400 seconds';
```


#### Decimal

DECIMAL annotation represents arbitrary-precision signed decimal
numebers of the form ```unscaledValue * 10^(-scale)```.

The primiative type stores an unscaled integer value.  The scale
stores the number of digits of that value that are to the right of the
decimal point, and the precision stores the maximum number of digits
supported in the unscaled value.

If not specified, the scale is 0.  Scale must be zero or a postive
integer less than the precision.  Precision is required and must be a
non-zero postive integer.  A precision too large for the underlying
type is an error.

DECIMAL can be used to annotate the following types:

1. `int64`: for 1 <= precision <=18
2. `int128`: for precision > 18

#### Timestamp

TIMESTAMP is value in microseconds and store in `int64` number.

### Time

TIME is used for a logical time witout a `date` with microsecond
precision.

It must annotate an `int64` that stores the number of microseconds
after midnight.

#### Date

DATE is used to for a logical date type, without a time of day.  It
must annotate an `int32` that stores the number of days from the Unix
epoch, 1 January 1970.


## ZMP File

A zonemap file is composed of an array of ZoneRec entries,
concatenated one after another. A ZoneRec stores characteristics,
range, and bloom-filter for a VV or FV. These information can be used
to filter out row groups in which all rows are disqualified. For
example, if we have a filter on age < 10, and the ZoneRec for
row-group R, column age, says minval is 21, then the rowgroup R could
be disqualified completely.

    struct xrg_zonerec_t {
      char magic[8];     /* XRGZMAP1 */
      int32_t rgidx;     /* aka row-group id */
      int16_t nfield;    /* aka #column */
      int16_t fieldidx;  /* aka column id */
      int16_t ptyp;
      int16_t ltyp;
      int16_t itemsz;
      char hasnull;
      char hasnonnull;
      char unused1;
      char unused2;
      char minval[128]; /* cutoff at 128 */
      char maxval[128]; /* cutoff at 128 */
      xrg_bloom_t bloom;
      char magic2[8];   /* XRGZMAP1 */
    };

## list.json File

A list.json file stores the path to all xrg file sorted by rowgroup
id. The file contains an array of file names.

```
[
"/path/to/T_0.xrg",
"/path/to/T_1.xrg",
"/path/to/T_2.xrg",
...
]
```

## schema.json File

A schema.json file stores the field names and types of the columns in the XRG file.

For example, here is the schema for the TPCH lineitem table.

```
[
   {"name":"l_orderkey", "type":"int64"},
   {"name":"l_partkey", "type":"int64"},
   {"name":"l_suppkey", "type":"int64"},
   {"name":"l_lineitem", "type":"int32"},
   {"name":"l_quantity", "type":"decimal", "precision":10, "scale":2},
   {"name":"l_extendedprice", "type":"decimal", "precision":10, "scale":2},
   {"name":"l_discount", "type":"fp32"},
   {"name":"l_tax", "type":"fp32"},
   {"name":"l_returnflag", "type":"string"},
   {"name":"l_linestatus", "type":"string"},
   {"name":"l_shipdate", "type":"date"},
   {"name":"l_commitdate", "type":"date"},
   {"name":"l_receiptdate", "type":"date"},
   {"name":"l_shipinstruct", "type":"string"},
   {"name":"l_shipmode", "type":"string"},
   {"name":"l_comment", "type":"string"}
]
```
