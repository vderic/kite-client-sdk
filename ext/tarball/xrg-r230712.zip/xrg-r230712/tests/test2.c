#undef NDEBUG
#define _LARGEFILE64_SOURCE
#define _POSIX_C_SOURCE 200809L
#include "harness.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Test vecbuf. Save some ints, floats, and strings */
int main() {

#ifdef NDEBUG
  fprintf(stderr, "warning: running in NON-DEBUG...\n");
#endif

  char errbuf[100];
  const int errbuflen = sizeof(errbuf);
  xrg_vecbuf_t *vbuf[8];
  vbuf[0] = xrg_vecbuf_create(XRG_PTYP_INT8, XRG_LTYP_NONE, 0, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[0]);
  vbuf[1] = xrg_vecbuf_create(XRG_PTYP_INT16, XRG_LTYP_NONE, 1, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[1]);
  vbuf[2] = xrg_vecbuf_create(XRG_PTYP_INT32, XRG_LTYP_NONE, 2, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[2]);
  vbuf[3] = xrg_vecbuf_create(XRG_PTYP_INT64, XRG_LTYP_NONE, 3, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[3]);
  vbuf[4] = xrg_vecbuf_create(XRG_PTYP_INT128, XRG_LTYP_NONE, 4, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[4]);
  vbuf[5] = xrg_vecbuf_create(XRG_PTYP_FP32, XRG_LTYP_NONE, 5, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[5]);
  vbuf[6] = xrg_vecbuf_create(XRG_PTYP_FP64, XRG_LTYP_NONE, 6, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[6]);
  vbuf[7] = xrg_vecbuf_create(XRG_PTYP_BYTEA, XRG_LTYP_STRING, 7, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[7]);

  for (int j = 0; j < 1000; j++) {
    char flag[10] = {0};
    int8_t i8[10];
    int16_t i16[10];
    int32_t i32[10];
    int64_t i64[10];
    __int128_t i128[10];
    float fp32[10];
    double fp64[10];
    char str[10][10];
    char *sptr[10];
    int slen[10];

    for (int i = 0; i < 10; i++) {
      i8[i] = i;
      i16[i] = i;
      i32[i] = i;
      i64[i] = i;
      i128[i] = i;
      fp32[i] = i;
      fp64[i] = i;
      sprintf(str[i], "%d%d%d%d", i, i, i, i);
      sptr[i] = str[i];
      slen[i] = strlen(sptr[i]);
    }

    CHECK(0 ==
          xrg_vecbuf_append_int8(vbuf[0], 10, i8, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int16(vbuf[1], 10, i16, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int32(vbuf[2], 10, i32, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int64(vbuf[3], 10, i64, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int128(vbuf[4], 10, i128, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_fp32(vbuf[5], 10, fp32, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_fp64(vbuf[6], 10, fp64, flag, errbuf, errbuflen));
    CHECK(0 == xrg_vecbuf_append_bytea(vbuf[7], 10, sptr, slen, flag, errbuf,
                                       errbuflen));
  }

  for (int i = 0; i < 8; i++) {
    CHECK(xrg_vecbuf_is_valid(vbuf[i]));
  }

  for (int i = 0; i < 8; i++) {
    CHECK(0 == xrg_vecbuf_compress(vbuf[i], errbuf, errbuflen));
    CHECK(xrg_vecbuf_is_compressed(vbuf[i]));
  }

  for (int i = 0; i < 8; i++) {
    CHECK(0 == xrg_vecbuf_uncompress(vbuf[i], errbuf, errbuflen));
    CHECK(!xrg_vecbuf_is_compressed(vbuf[i]));
  }

  /* try extract bytea */
  {
    char *ptr[10000];
    int len[10000];
    CHECK(0 == xrg_vecbuf_extract_bytea(vbuf[7], 10000, ptr, len, errbuf,
                                        errbuflen));

    // check content
    int k = 0;
    for (int j = 0; j < 1000; j++) {
      char str[10][10];
      for (int i = 0; i < 10; i++, k++) {
        sprintf(str[i], "%d%d%d%d", i, i, i, i);
        CHECK(0 == memcmp(str[i], ptr[k], len[k]));
      }
    }
  }

  /* write to file */
  const char *OUTFILE = "test2.xrg";
  CHECK(0 == xrg_file_create(OUTFILE, 8, vbuf, errbuf, errbuflen));

  /* read from file */
  int fd = open(OUTFILE, O_RDONLY, 0);
  CHECK(fd >= 0);
  xrg_vecoff_t *vecoff = xrg_vecoff_from_file(fd, errbuf, errbuflen);
  CHECK(vecoff);
  CHECK(vecoff->nvec == 8);

  xrg_vecbuf_t *xx[8];
  for (int i = 0; i < 8; i++) {
    CHECK(-1 != lseek64(fd, vecoff->offset[i], SEEK_SET));
    xx[i] = xrg_vecbuf_read(fd, errbuf, errbuflen);
    CHECK(xx[i]);
    if (i != 7) {
      CHECK(vecoff->offset[i + 1] == lseek64(fd, 0, SEEK_CUR));
    }

    // check the content of xx[i] is the same as vbuf[i]
    CHECK(0 == memcmp(&xx[i]->header, &vbuf[i]->header, sizeof(xx[i]->header)));
    CHECK(xx[i]->datatop == vbuf[i]->datatop);
    CHECK(xx[i]->flagtop == vbuf[i]->flagtop);
    CHECK(0 == memcmp(xx[i]->data, vbuf[i]->data, xx[i]->datatop));
    CHECK(0 == memcmp(xx[i]->flag, vbuf[i]->flag, xx[i]->flagtop));
  }
  xrg_vecoff_release(vecoff);

  close(fd);

  /* clean up */
  for (int i = 0; i < 8; i++) {
    xrg_vecbuf_release(vbuf[i]);
    xrg_vecbuf_release(xx[i]);
  }
  return 0;
}
