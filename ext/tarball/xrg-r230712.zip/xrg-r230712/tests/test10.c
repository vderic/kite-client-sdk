#include "harness.h"
#include <stdio.h>

static void section1() {
  const char *p;
  int32_t d;
  const char *endp;
  char buf[100];

  // unix epoch day 0
  p = "1970-01-01"; /* use DASH */
  CHECK(0 == xrg_date_parse(&d, p, &endp));
  CHECK(0 == d);
  CHECK(*endp == 0);

  // unix epoch + 0 day
  p = "1970/01/01"; /* use SLASH */
  CHECK(0 == xrg_date_parse(&d, p, &endp));
  CHECK(0 == d);
  CHECK(*endp == 0);

  CHECK(0 == strcmp("1970-01-01", xrg_date_str(d, buf, sizeof(buf))));

  // epoch + 1 day
  p = "1970/01/02";
  CHECK(0 == xrg_date_parse(&d, p, &endp));
  CHECK(1 == d);
  CHECK(*endp == 0);

  CHECK(0 == strcmp("1970-01-02", xrg_date_str(d, buf, sizeof(buf))));

  // epoch + 2 day
  p = "1970/01/02x";
  CHECK(0 == xrg_date_parse(&d, p, &endp));
  CHECK(1 == d);
  CHECK(*endp == 'x');

  // epoch minus 1 day
  p = "1969/12/31";
  CHECK(0 == xrg_date_parse(&d, p, &endp));
  CHECK(-1 == d);
  CHECK(*endp == 0);
  CHECK(0 == strcmp("1969-12-31", xrg_date_str(d, buf, sizeof(buf))));
}

static void section2() {
  const char *p;
  int64_t t;
  const char *endp;
  char buf[100];

  p = "00:00:00.1";
  CHECK(0 == xrg_time_parse(&t, p, &endp));
  CHECK(t == 100000);
  CHECK(*endp == 0);
  CHECK(0 == strcmp(p, xrg_time_str(t, buf, sizeof(buf))));

  p = "00:00:00.11001";
  CHECK(0 == xrg_time_parse(&t, p, &endp));
  CHECK(t == 110010);
  CHECK(*endp == 0);
  CHECK(0 == strcmp(p, xrg_time_str(t, buf, sizeof(buf))));

  p = "00:02:00.11001";
  CHECK(0 == xrg_time_parse(&t, p, &endp));
  CHECK(t == 2 * 60 * 1000000 + 110010);
  CHECK(*endp == 0);

  p = "00:02:00.1100145678";
  CHECK(0 == xrg_time_parse(&t, p, &endp));
  CHECK(0 == strcmp("00:02:00.110014", xrg_time_str(t, buf, sizeof(buf))));

  p = "01:02:03.x";
  CHECK(0 == xrg_time_parse(&t, p, &endp));
  CHECK(t == ((int64_t)1 * 60 * 60 + 2 * 60 + 3) * 1000000);
  CHECK(*endp == 'x');
  CHECK(0 == strcmp("01:02:03", xrg_time_str(t, buf, sizeof(buf))));

  p = "00:00:00.02"; // 20 millisec
  CHECK(0 == xrg_time_parse(&t, p, &endp));
  CHECK(t == 20000);
  CHECK(0 == strcmp(p, xrg_time_str(t, buf, sizeof(buf))));

  p = "00:00:00.000001"; // 1 usec
  CHECK(0 == xrg_time_parse(&t, p, &endp));
  CHECK(t == 1);
  CHECK(0 == strcmp(p, xrg_time_str(t, buf, sizeof(buf))));
}

static void section3() {
  const char *p;
  int64_t ts;
  const char *endp;
  char buf[100];

  p = "1970-01-01 00:00:00.1";
  CHECK(0 == xrg_timestamp_parse(&ts, p, &endp));
  CHECK(ts == 100000);
  CHECK(*endp == 0);

  p = "1970-01-01 00:00:00.1Z";
  CHECK(0 == xrg_timestamp_parse(&ts, p, &endp));
  CHECK(ts == 100000);
  CHECK(*endp == 0);
  CHECK(0 == strcmp("1970-01-01 00:00:00.1",
                    xrg_timestamp_str(ts, buf, sizeof(buf))));

  p = "1970-01-01 00:00:00.1x";
  CHECK(0 == xrg_timestamp_parse(&ts, p, &endp));
  CHECK(ts == 100000);
  CHECK(*endp == 'x');

  p = "1970-01-01 00:00:00+01";
  CHECK(0 == xrg_timestamp_parse(&ts, p, &endp));
  CHECK(ts == (int64_t)-1 * 60 * 60 * 1000000);
  CHECK(*endp == 0);

  p = "1970-01-01 00:00:00-01:30x";
  CHECK(0 == xrg_timestamp_parse(&ts, p, &endp));
  CHECK(ts == (int64_t)(90 * 60) * 1000000);
  CHECK(*endp == 'x');
  CHECK(0 ==
        strcmp("1970-01-01 01:30:00", xrg_timestamp_str(ts, buf, sizeof(buf))));

  p = "1970-01-02 00:00:01x";
  CHECK(0 == xrg_timestamp_parse(&ts, p, &endp));
  CHECK(ts == ((int64_t)24 * 60 * 60 + 1) * 1000000);
  CHECK(*endp == 'x');
  CHECK(0 ==
        strcmp("1970-01-02 00:00:01", xrg_timestamp_str(ts, buf, sizeof(buf))));

  // negative ts
  p = "1969-12-31 23:59:59";
  CHECK(0 == xrg_timestamp_parse(&ts, p, &endp));
  CHECK(ts == ((int64_t)-1) * 1000000);
  CHECK(*endp == 0);
  CHECK(0 ==
        strcmp("1969-12-31 23:59:59", xrg_timestamp_str(ts, buf, sizeof(buf))));
}

static void section4() {
  const char *p;
  const char *endp;
  xrg_interval_t interval;
  char buf[100];

  p = "1 year 2 months 3 days";
  CHECK(0 == xrg_interval_parse(&interval, p, &endp));
  CHECK(interval.mon == 14);
  CHECK(interval.day == 3);
  CHECK(interval.usec == 0);
  CHECK(*endp == 0);
  CHECK(0 ==
        strcmp("14 mons 3 days", xrg_interval_str(interval, buf, sizeof(buf))));

  p = "-1 year 2 months 3 days";
  CHECK(0 == xrg_interval_parse(&interval, p, &endp));
  CHECK(interval.mon == -10);
  CHECK(interval.day == 3);
  CHECK(interval.usec == 0);
  CHECK(*endp == 0);
  CHECK(0 == strcmp("-10 mons 3 days",
                    xrg_interval_str(interval, buf, sizeof(buf))));

  p = "1 day 02:03:04.567x";
  CHECK(0 == xrg_interval_parse(&interval, p, &endp));
  CHECK(interval.mon == 0);
  CHECK(interval.day == 1);
  CHECK(*endp == 'x');
  CHECK(0 == strcmp("1 day 02:03:04.567",
                    xrg_interval_str(interval, buf, sizeof(buf))));
}

int main() {

#ifdef NDEBUG
  fprintf(stderr, "warning: running in NON-DEBUG...\n");
#endif

  printf("  ... section1\n");
  section1();
  printf("  ... section2\n");
  section2();
  printf("  ... section3\n");
  section3();
  printf("  ... section4\n");
  section4();
  return 0;
}
