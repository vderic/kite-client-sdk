#ifndef TEST_H
#define TEST_H

#include "../src/xrg.h"
#include <stdlib.h>

#define xstr(s) STRINGIFY(s)
#define STRINGIFY(s) #s

static void fatal(const char *cond, int line) {
  fprintf(stderr, "Assertion (%s) failed at line %d\n", cond, line);
  abort();
}

// clang-format off
#define CHECK(x)    if (x) ; else fatal(STRINGIFY(x), __LINE__)
// clang-format on


#endif
