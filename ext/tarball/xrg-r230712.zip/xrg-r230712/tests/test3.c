#include "harness.h"
#include <stdio.h>
#include <stdlib.h>

// Test bytea encoding and decoding
int main() {

#ifdef NDEBUG
  fprintf(stderr, "warning: running in NON-DEBUG...\n");
#endif

  char errbuf[100];
  const int errbuflen = sizeof(errbuf);
  xrg_vecbuf_t *vbuf = xrg_vecbuf_create(XRG_PTYP_BYTEA, XRG_LTYP_STRING, 0, 0,
                                         0, errbuf, errbuflen);
  CHECK(vbuf);

  char *ptr[3];
  int len[3];
  char flag[3] = {0};
  ptr[0] = "";
  ptr[1] = "a";
  ptr[2] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
           "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
           "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
           "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
  for (int i = 0; i < 3; i++) {
    len[i] = strlen(ptr[i]);
  }

  CHECK(0 ==
        xrg_vecbuf_append_bytea(vbuf, 3, ptr, len, flag, errbuf, errbuflen));
  CHECK(xrg_vecbuf_is_valid(vbuf));

  char *xxptr[3];
  int xxlen[3];
  CHECK(0 ==
        xrg_vecbuf_extract_bytea(vbuf, 3, xxptr, xxlen, errbuf, errbuflen));
  for (int i = 0; i < 3; i++) {
    CHECK(len[i] == xxlen[i]);
    CHECK(0 == memcmp(xxptr[i], ptr[i], len[i]));
  }
  xrg_vecbuf_release(vbuf);
  return 0;
}
