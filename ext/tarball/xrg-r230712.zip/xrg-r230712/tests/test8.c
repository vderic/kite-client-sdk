#define _LARGEFILE64_SOURCE
#define _POSIX_C_SOURCE 200809L
#include "harness.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Test xrg_file_read() */
int main() {

#ifdef NDEBUG
  fprintf(stderr, "warning: running in NON-DEBUG...\n");
#endif

  char errbuf[100];
  const int errbuflen = sizeof(errbuf);
  xrg_vector_t *vec = xrg_vector_create_ex(100, XRG_PTYP_INT32, XRG_LTYP_NONE,
                                           -1, 0, 0, errbuf, errbuflen);
  CHECK(vec);

  for (int i = 0; i < 100; i++) {
    ((int32_t *)XRG_VECTOR_DATA(vec))[i] = i;
  }

  int rc = xrg_vector_print(stdout, 1, (const xrg_vector_t **)&vec, '|', "NULL", errbuf,
          	         errbuflen);
  CHECK(0 == rc);

  /* clean up */
  xrg_vector_release(vec);
  return 0;
}
